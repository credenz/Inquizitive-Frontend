const Instructions = () => {
    return ( 
        <div className="inst">
            <h1>Bolo</h1>
        </div>
     );
}
 
export default Instructions;