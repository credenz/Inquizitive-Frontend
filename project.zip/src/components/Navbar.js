// import { Link } from "react-router-dom";
// const Navbar = () => {
//   return (
//     <div className="navbar">
//       <img src="\images\PISB color (1).png" alt="" className="pic"/>
//       <nav className="nav-content">
//         <ul>
//           <li><Link to="/team">Our Team</Link></li>
//           <li><Link to="/instructions">Instructions</Link></li>
//         </ul>
//       </nav>
//     </div>
//   );
// };

// export default Navbar;
