// import "../App.css";
// import React,{useState, SyntheticEvent} from "react"
// import {Redirect} from 'react-router-dom';

// const Home = () => {
//   const [username, setUsername] = useState('Rohit');
//   const [password, setPassword] = useState('ronda');
//   const [redirect, setRedirect] = useState(false);

//   const submit = async (e: SyntheticEvent) => {
//     e.preventDefault();
//     await fetch('http://localhost:8000/api/users', {
//       method: 'POST',
//       headers: {'Content-Type': 'application/json'},
//       credentials: 'include',
//       body: JSON.stringify({
//         username,
//         password
//       })
//     });
//     setRedirect(true);
//   }

//   if (redirect) {
//     return <Redirect to="/instructions"/>
//   }

//   return (
//     <form onSubmit={submit}>
//       <label>Username</label>
//       <input
//       type="text"
//       placeholder="Username"
//       required
//       onChange={e => setUsername(e.target.value)}
//       />
//       <label>Password</label>
//       <input
//       type="password"
//       placeholder="Password"
//       required
//       onChange={e => setPassword(e.target.value)}
//       />
//       <button type="submit">Login</button>
//     </form>
//   );
// };

// export default Home;

import "../App.css";
import { Link, NavLink } from "react-router-dom";
const Home = () => {
  return (
    <div className="home">

      <nav className="navbar navbar-expand-lg navbar-light bg-light">
        <div className="container-fluid">
          <a className="navbar-brand" href="#asda">
            <img src="\images\PISB color (1).png" alt="" className="pic" />
          </a>
          <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span className="navbar-toggler-icon"></span>
          </button>
          <div className="collapse navbar-collapse" id="navbarNav">
            <ul className="navbar-nav">
              <li>
                <NavLink to='/instructions' className='nav-item  w-5 m-3 p-0'> Instructions </NavLink>
              </li>
              <li className='nav-item w-5'>
                <NavLink to='/team' className='m-3 p-0'> Our Team </NavLink>
              </li>
            </ul>
          </div>
        </div>

      </nav>

      <section class="wrapper">
        <div id="stars"></div>
        <div id="stars2"></div>
        <div id="stars3"></div>
      </section>
      <div className='home-content row text-center'>
        <div className='col-lg-6 p-5'>
          <div className="login">
            {/* <div className="loginContainer"> */}
            {/* <img src="\images\maxresdefault.jpg" alt="" /> */}
            <label>Username</label>
            <input type="text" placeholder="Username" />
            <label>Password</label>
            <input type="password" placeholder="Password" />
            <button type="submit">Login</button>
            {/* </div> */}
          </div>
        </div>
        <div className="left col-lg-6 p-5">
          <img src="\images\l.png" alt="logo" />
          <h2>presents</h2>
          <h1>InQuizitive</h1>
        </div>
        <footer>PISB WEB TEAM</footer>
      </div>

    </div>
  );
};

export default Home;
